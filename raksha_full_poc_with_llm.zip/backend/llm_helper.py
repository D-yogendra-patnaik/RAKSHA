import os
import openai
from dotenv import load_dotenv
load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")  # change as needed

def call_openai_chat(system_prompt, user_prompt, max_tokens=256, temperature=0.2):
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY not set")
    openai.api_key = OPENAI_API_KEY
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt}
    ]
    resp = openai.ChatCompletion.create(
        model=OPENAI_MODEL,
        messages=messages,
        max_tokens=max_tokens,
        temperature=temperature
    )
    try:
        content = resp['choices'][0]['message']['content'].strip()
    except Exception:
        content = str(resp)
    return content

def generate_feedback(simulation, action):
    system = "You are an expert cybersecurity coach. Provide concise, clear feedback for end users explaining red flags and safe actions."
    user_prompt = f\"\"\"Scenario title: {simulation.get('title')}
Scenario content: {simulation.get('scenario')}
Red flags: {', '.join(simulation.get('red_flags', []))}
User action: {action}

Provide a short feedback paragraph (1-3 sentences) explaining whether the action was correct, why, and one simple next step the user should take. Keep language simple and friendly for non-technical users.\"\"\"
    try:
        return call_openai_chat(system, user_prompt)
    except Exception as e:
        if action == simulation.get('correct_action'):
            return simulation.get('mentor_feedback', {}).get('correct', "Good job. That was the right action.")
        else:
            return simulation.get('mentor_feedback', {}).get('incorrect', "That action seems risky. Be careful and verify.") 
