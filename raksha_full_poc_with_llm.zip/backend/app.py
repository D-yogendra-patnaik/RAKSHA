from flask import Flask, jsonify, request, g
import os
try:
    import llm_helper
    LLM_AVAILABLE = True
except Exception:
    LLM_AVAILABLE = False

from flask_cors import CORS
import sqlite3, json, datetime, os

DATABASE = 'raksha.db'
SIM_FILE = 'simulations.json'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

def init_db(app):
    with app.app_context():
        db = get_db()
        cur = db.cursor()
        # users table
        cur.execute("""CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            display_name TEXT,
            created_at TEXT
        )""")
        # progress table
        cur.execute("""CREATE TABLE IF NOT EXISTS progress (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user TEXT,
            simulation_id TEXT,
            action TEXT,
            score_delta INTEGER,
            success INTEGER,
            ts TEXT
        )""")
        db.commit()

app = Flask(__name__)
CORS(app)

# load simulations
with open(SIM_FILE, 'r') as f:
    SIMULATIONS = json.load(f)

@app.before_first_request
def setup():
    init_db(app)

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

@app.route('/api/register', methods=['POST'])
def register():
    data = request.json or {}
    username = data.get('username','guest')
    display = data.get('display','Guest')
    db = get_db()
    try:
        db.execute("INSERT INTO users (username, display_name, created_at) VALUES (?, ?, ?)",
                   (username, display, datetime.datetime.utcnow().isoformat()))
        db.commit()
    except Exception as e:
        # user might exist; ignore
        pass
    return jsonify({"ok": True, "username": username, "display": display})

@app.route('/api/simulations', methods=['GET'])
def get_simulations():
    age_group = request.args.get('age_group','all')
    if age_group == 'all':
        sims = SIMULATIONS
    else:
        sims = [s for s in SIMULATIONS if age_group in s.get('age_groups',[])]
    return jsonify({"simulations": sims})

@app.route('/api/simulation/<sid>', methods=['GET'])
def get_simulation(sid):
    sim = next((s for s in SIMULATIONS if s['id']==sid), None)
    if not sim:
        return jsonify({"error":"not found"}), 404
    return jsonify(sim)

@app.route('/api/submit_response', methods=['POST'])
def submit_response():
    data = request.json or {}
    sim_id = data.get('simulation_id')
    action = data.get('action')
    user = data.get('user','guest')
    sim = next((s for s in SIMULATIONS if s['id']==sim_id), None)
    if not sim:
        return jsonify({"error":"invalid simulation"}), 400

    correct = sim.get('correct_action')
    ts = datetime.datetime.utcnow().isoformat()
    success = 1 if action==correct else 0
    score_delta = 10 if success else -5

    db = get_db()
    db.execute("INSERT INTO progress (user, simulation_id, action, score_delta, success, ts) VALUES (?, ?, ?, ?, ?, ?)",
               (user, sim_id, action, score_delta, success, ts))
    db.commit()

    if LLM_AVAILABLE and os.getenv('OPENAI_API_KEY'):
        try:
            feedback = llm_helper.generate_feedback(sim, action)
        except Exception:
            feedback = sim['mentor_feedback']['correct'] if success else sim['mentor_feedback']['incorrect']
    else:
        feedback = sim['mentor_feedback']['correct'] if success else sim['mentor_feedback']['incorrect']

    # simple level calc and totals
    cur = db.execute("SELECT SUM(score_delta) as total FROM progress WHERE user=?", (user,))
    row = cur.fetchone()
    total = row['total'] or 0

    level = 1 + max(0, total // 50)

    return jsonify({"success": bool(success), "score_delta": score_delta, "total_score": total, "level": level, "feedback": feedback})

@app.route('/api/progress', methods=['GET'])
def get_progress():
    user = request.args.get('user','guest')
    db = get_db()
    cur = db.execute("SELECT simulation_id, action, score_delta, success, ts FROM progress WHERE user=? ORDER BY ts DESC LIMIT 50", (user,))
    rows = [dict(r) for r in cur.fetchall()]
    cur2 = db.execute("SELECT SUM(score_delta) as total FROM progress WHERE user=?", (user,))
    row = cur2.fetchone()
    total = row['total'] or 0
    level = 1 + max(0, total // 50)
    return jsonify({"events": rows, "total_score": total, "level": level})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
