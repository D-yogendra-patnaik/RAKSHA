
import React from "react";
export default function SimulationCard({sim, onStart}){
  return (
    <div className="card">
      <h3>{sim.title}</h3>
      <div className="meta">{sim.type} · {sim.difficulty}</div>
      <p className="excerpt">{sim.scenario.subject ? sim.scenario.subject : (sim.scenario.message || sim.scenario.body ? (sim.scenario.message || sim.scenario.body).slice(0,100) : "")}</p>
      <div className="card-actions"><button onClick={onStart}>Start</button></div>
    </div>
  )
}
