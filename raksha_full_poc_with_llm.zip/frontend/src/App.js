
import React, {useState, useEffect} from "react";
import axios from "axios";
import SimulationCard from "./SimulationCard";
import MentorChat from "./MentorChat";
import Dashboard from "./Dashboard";

function App(){
  const [ageGroup, setAgeGroup] = useState("all");
  const [sims, setSims] = useState([]);
  const [current, setCurrent] = useState(null);
  const [user, setUser] = useState("guest");
  const [progress, setProgress] = useState({total_score:0, events:[]});

  useEffect(()=>{
    fetchSims();
    fetchProgress();
    // register guest user
    axios.post("http://localhost:5000/api/register", {username: user, display: "Guest"}).catch(()=>{})
  }, [ageGroup]);

  function fetchSims(){
    axios.get(`http://localhost:5000/api/simulations?age_group=${ageGroup}`)
      .then(r=>setSims(r.data.simulations))
      .catch(e=>console.error(e));
  }
  function fetchProgress(){
    axios.get(`http://localhost:5000/api/progress?user=${user}`)
      .then(r=>setProgress(r.data))
      .catch(e=>console.error(e));
  }

  function startSimulation(sim){
    setCurrent(sim);
  }
  function submit(simId, action){
    axios.post("http://localhost:5000/api/submit_response", {simulation_id: simId, action: action, user: user})
      .then(r=>{
        alert(r.data.feedback);
        fetchProgress();
        setCurrent(null);
      }).catch(e=>{console.error(e); alert("Error")});
  }

  return (
    <div className="app">
      <header className="header"><h1>RAKSHA — Cyber Defense Trainer</h1>
        <div className="controls">
          <label>Age group:</label>
          <select value={ageGroup} onChange={e=>setAgeGroup(e.target.value)}>
            <option value="all">All</option>
            <option value="seniors">Seniors</option>
            <option value="young">Young</option>
          </select>
        </div>
      </header>
      <main className="main">
        <aside className="sidebar"><Dashboard progress={progress} /></aside>
        <section className="content">
          {!current && sims.map(s=>(<SimulationCard key={s.id} sim={s} onStart={()=>startSimulation(s)} />))}
          {current && <MentorChat sim={current} onSubmit={submit} onCancel={()=>setCurrent(null)} />}
        </section>
      </main>
      <footer className="footer">RAKSHA PoC — demo content is synthetic and sandboxed.</footer>
    </div>
  )
}
export default App;
