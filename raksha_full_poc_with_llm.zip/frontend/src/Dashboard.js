
import React from "react";
export default function Dashboard({progress}){
  const ts = progress.events || [];
  const score = progress.total_score || 0;
  const level = progress.level || 1;
  return (
    <div className="dashboard">
      <h3>Your Progress</h3>
      <div className="score">Score: {score}</div>
      <div className="level">Level: {level}</div>
      <h4>Recent</h4>
      <ul>{ts.slice(0,5).map((e,i)=>(<li key={i}>{e.simulation_id} — {e.action} ({e.score_delta})</li>))}</ul>
    </div>
  )
}
