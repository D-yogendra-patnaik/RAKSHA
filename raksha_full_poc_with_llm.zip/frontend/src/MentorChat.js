
import React, {useState} from "react";
export default function MentorChat({sim, onSubmit, onCancel}){
  const [action, setAction] = useState("");
  return (
    <div className="mentor">
      <div className="sim-header"><h2>{sim.title}</h2><div className="tag">{sim.type} · {sim.difficulty}</div></div>
      <div className="sim-body">
        <pre className="scenario">{sim.scenario.subject ? ("From: "+sim.scenario.from+"\\nSubject: "+sim.scenario.subject+"\\n\\n"+sim.scenario.body) : (sim.scenario.message||sim.scenario.body)}</pre>
        <div className="flags"><strong>Red Flags:</strong><ul>{sim.red_flags.map((r,i)=>(<li key={i}>{r}</li>))}</ul></div>
      </div>
      <div className="actions">
        <label>Choose action</label>
        <div className="act-btns">{sim.user_actions.map(a=>(<button key={a} className={action===a?'sel':''} onClick={()=>setAction(a)}>{a}</button>))}</div>
        <div className="controls"><button disabled={!action} onClick={()=>onSubmit(sim.id, action)}>Submit</button> <button onClick={onCancel}>Cancel</button></div>
      </div>
    </div>
  )
}
