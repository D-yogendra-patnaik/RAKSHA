RAKSHA Full PoC
===============

This package contains a full proof-of-concept website for RAKSHA (Frontend + Backend) with:
- Flask backend with SQLite storing progress and serving simulations
- React frontend (simple, clean UI) to run simulations, submit actions and see feedback
- Dockerfiles + docker-compose to run both services easily

Quick starts (local):
1) Python backend (developer mode)
   cd backend
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   python app.py

2) Frontend
   cd frontend
   npm install
   npm start

3) Docker (both)
   docker-compose up --build

Notes:
- Simulations are synthetic and stored in backend/simulations.json
- For production, integrate a real LLM for AI mentor feedback, secure auth, and HTTPS.


LLM Integration:
- To enable dynamic AI Mentor feedback, set OPENAI_API_KEY in a .env file in the project root (see .env.example).
- The backend will call OpenAI to generate concise feedback. Ensure network access and API key are configured securely.
